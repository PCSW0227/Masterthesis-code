# -*- coding: utf-8 -*-

import csv

def save_to_file(data, filename):
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(data)

# 대답 내용1
answer1 = """
[]
"""


save_to_file(answer1, 'C:\\Users\\wkdal\\Desktop\\2023\\04. 석사 학위 논문\\03.데이터\\summary\\38마인\\마인1.csv')


# 대답 내용2
answer2 = """
[]
"""

save_to_file(answer2, 'C:\\Users\\wkdal\\Desktop\\2023\\04. 석사 학위 논문\\03.데이터\\summary\\38마인\\마인2.csv')

