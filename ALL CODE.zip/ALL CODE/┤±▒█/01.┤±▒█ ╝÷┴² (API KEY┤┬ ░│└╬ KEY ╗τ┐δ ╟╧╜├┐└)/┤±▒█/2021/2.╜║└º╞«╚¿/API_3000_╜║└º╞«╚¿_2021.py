# 먼저, "API 호출"이란 ? API는 우리가 어떤 서비스를 소통하기 위한 도구라고 생각하면 쉽다.
#                      호출한다는 것은 API도구를 활용해서 서비스에게 무언가를 요청하는 것이다.
#                      그런데 YOUTUBE는 API 호출 횟수의 한계를 하루에 10000단위로 정했다.이를 쿼터라고 한다.
#                      쿼터는 한정된 자원이라 너무 많이 사용하지 않도록 주의를 기울여야 한다.
#                      EX. 아이스크림을 가게 주인이 하루에 5개만 팔고, 우리는 5개까지만 살 수 있음.

import schedule       #일정관리 라이브러리
import time

class YouTubeComments:
    def __init__(minji_instance):
        minji_instance.start_comment = 0
        minji_instance.limit_comments = 3000
        minji_instance.video_id = ""

    def total_comments(minji_instance):
        if minji_instance.start_comments >= minji_instance.limit_comments:
            print("Youtube API 수집 쿼터를 3000단위 채웠습니다. 이 이상은 수집할 수 없습니다.")
            return False  #3000이 넘으면 함수를 반환한다.
        else :
            minji_instance.start_comments += 1
            return True

    def everyday_time(minji_instance):
        if not total_comments(minji_instance):   #total_comments함수는 3000까지 제한이 걸려있는 함수인데,
            return                   #if not total_comments는 3000이 넘으면(==False) 함수 실행을 중단하고 반환
                                     #안넘었으면 계속 함수를 실행.
        minji_instance.video_id = ""             #채널아이디
        comments3 = youtube_comments3("") #채널아이디에서 가져온 댓글을 comments3에 넣기
        print(comments3)

#mj = YouTubeComments()
#schedule.every().day.at("11:00").do(mj.everyday_time)  #컴퓨터가 켜져있을경우 11:00에 자동 수집

#while True:                       #while루프 아래에 있는 코드는 무한 반복이다.
    #schedule.run_pending()        #예약된 작업이 있다면 (11시)에 실행해라. 즉, 지금 당장 실행할 일이 있는지 확인하고 실행하라는 뜻.
    #time.sleep(1)                 #1초 동안 실행을 멈추게 된다. 빠르게 가동되는 것을 방지.즉, 1초동안 쉬기.






