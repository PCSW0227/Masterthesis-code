from googleapiclient.discovery import build

class YouTubeComments:
    def __init__(minji_instance):                   #YouTubeCommnets 클래스의 인스턴스가 생성될 때 자동으로 호출
        minji_instance.start_comments = 0           #현재까지 수집한 댓글의 수
        minji_instance.limit_comments = 600         #댓글을 수집 최대 한도
        minji_instance.video_id = "2ztYBjHn1nU"     #댓글을 수집하려는 동영상 ID
        minji_instance.pages_retrieved = 0          #현재까지 조회한 페이지 수

        developerKey = "AIzaSyAY20vWTWZHfiIH250_JXWtMk9KuWumvEU"                           #나의 API Key

        # 유튜브 서비스 객체 초기화
        minji_instance.youtube = build("youtube", "v3", developerKey=developerKey)

    def total_comments(minji_instance):                                                     #이 메소드는 현재까지 수집한 댓글의 수가 한도를 초과했는지 확인. 초과하면 False를 반환하고, 그렇지 않을 경우 True를 반환
        if minji_instance.start_comments >= minji_instance.limit_comments:
            print("Youtube API 수집 쿼터를 1000단위 채웠습니다. 이 이상은 수집할 수 없습니다.")
            return False  #1000이 넘으면 함수를 반환한다.
        else :
            minji_instance.start_comments += 1
            return True

    def youtube_comments3(minji_instance, video_id, page_token=None):   #이 메소드는 특정 비디오의 댓글을 수집
        all_comments = []
        count = 0
        while page_token or count == 0:
            response = minji_instance.youtube.commentThreads().list(
                part="snippet",
                videoId = video_id,
                pageToken = page_token,
                maxResults=400
            ).execute()

            all_comments.extend(response.get("items",[]))
            page_token = response.get("nextPageToken")

            count += 1
            if count >= 20:
                break

        return all_comments, page_token

    def get_comments(minji_instance,video_id , page_token=None):                            #상기 youtube_comments3메소드를 호출하여 해당 동영상 id의 댓글을 수집
        comments, next_page_token = minji_instance.youtube_comments3("2ztYBjHn1nU")
        return comments, next_page_token

