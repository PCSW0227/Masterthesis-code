from googleapiclient.discovery import build
from API미끼3 import YouTubeComments
import pandas as pd

#나의 API키 (GoogleCloud에서 API 서비스를 이용하면 됩니다. 프로젝트를 생성 후에 공개키로 API키를 발급받아주세요)
developerKey = "AIzaSyAY20vWTWZHfiIH250_JXWtMk9KuWumvEU"
#유튜브 API키의 최신 버전
YOUTUBE_API_VERSION = "v3"
#유튜브 API키의 서비스 이름
YOUTUBE_API_SERVICE_NAME = "youtube"

yt_comments = YouTubeComments()

comments, token = yt_comments.get_comments("VRQB-fn4Q14")

def youtube_comments(video_id, page_token=None):
    my_serviece = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, developerKey=developerKey)

    results = my_serviece.commentThreads().list(
        part = "snippet",
        videoId = video_id,
        textFormat="plainText",
        pageToken=page_token #추가된 코드 : 페이지 토큰 활용
    ).execute()

    comments = []

    for item in results['items']:
        comment = item['snippet']['topLevelComment']['snippet']
        author = comment['authorDisplayName']
        text = comment['textDisplay']
        published_at = comment['publishedAt']
        comments.append({
            'author' : author,
            'text' : text,
            'published_at' : published_at
        })
    return comments, results.get('nextPageToken', None)

#페이지 단위로 댓글을 가져와 csv로 저장
MAX_PAGES = 20
page_token = None
page_count = 1

base_filepath = 'C:\\Users\\wkdal\\Desktop\\2023\\04. 석사 학위 논문\\03.데이터\\Youtube-data\\2023미끼\\2023미끼3'
while page_count <= MAX_PAGES:
    comments, next_page_token = youtube_comments("VRQB-fn4Q14", page_token)
    df_result = pd.DataFrame(comments)

    #파일 경로에 페이지 번호를 추가하여 파일 이름을 변경
    csv_filepath = f"{base_filepath}_page{page_count}.csv"
    df_result.to_csv(csv_filepath, index=False)

    page_count += 1
    page_token = next_page_token



