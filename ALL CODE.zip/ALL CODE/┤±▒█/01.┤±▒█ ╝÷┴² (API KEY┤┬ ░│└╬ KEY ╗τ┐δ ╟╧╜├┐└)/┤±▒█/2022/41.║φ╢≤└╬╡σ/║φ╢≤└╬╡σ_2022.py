from apiclient.discovery import build
from API블라인드 import YouTubeComments
import schedule
import time

#Python의 리스트로 저장하는 방법이 끝나면, HDFS 파일로 저장해서 하둡에서 사용해야됨#
##먼저, ANACONDA PROMPT에서 pip install pyarrow라는 라이브러리를 설치합니당. 이 라이브러리는 Hadoop과 통신을
#가능하게 해주는 라이브러리입니다.
#import pyarrow
#from pyarrow import hdfs
# Hadoop 파일 시스템에 연결
#fs= pyarrow.hdfs.HadoopFileSystem('localhost', 9000)  # 주의: 'localhost'와 '9000'은 각각 Hadoop의 호스트명과 포트 번호입니다. 실제 시스템에 맞게 변경해야 합니다.


#나의 API키 (GoogleCloud에서 API 서비스를 이용하면 됩니다. 프로젝트를 생성 후에 공개키로 API키를 발급받아주세요)
developerKey = "AIzaSyAY20vWTWZHfiIH250_JXWtMk9KuWumvEU"
#유튜브 API키의 최신 버전
YOUTUBE_API_VERSION = "v3"
#유튜브 API키의 서비스 이름
YOUTUBE_API_SERVICE_NAME = "youtube"

#build 함수란? goolgeclient library에 포함된 함수로, 특정 Google API와 상호작용 하기 위한 서비스 객체를
#생성하는데 사용됩니다.. build(유튜브API서비스이름, 유튜브 버전, 나의 API KEY)
#commentThreads()함수는 Youtube data API의 일부로, Youtube 비디오에 달린 댓글 스레드를 조회하는데 사용합니다.
#컴퓨터 과학에서 "스레드"란 특정 프로그램 내에서 실행되는 "하나의 독립적인 흐름 단위"입니다.
#여러 스레드를 사용하면 동시에 작업처리를 할 수 있습니다.
#여기서는 "댓글 스레드"를 말하며 "댓글 스레드"는 "부모 댓글(대댓글)"과 자식댓글(댓글)
#에 대한 대답(반응)을 그룹화합니다. 이러한 방식으로 "하나의 독립적인 흐름 단위"가 형성 됩니다.

#commentThreads().list() api를 사용하면 댓글 스레드를 조회할 수 있고, 리스트 형태로 반환합니다.
#part="snippet"?
#part는 Youtube data API의 메서드에 대한 인자(argument)이름이며, 고정된 이름이다.
#snippet은 댓글 스레드의 기본적인 정보인 작성자,작성시각,내용 필드를 포함하도록 지시하는 키워드입니다.
#videoID = "video_id" 이 인수는 댓글 스레드를 조회하려는 비디오의 ID를 저장합니다. 실행되기 전에 설정되어야한다.
#TextFormat = "plainText 이 인수는 댓글의 텍스트 형식을 지정합니다. plainText는 댓글을 일반 텍스트 형태로
#반환하라는 의미입니다


def youtube_comments(video_id):
    my_serviece = build(YOUTUBE_API_SERVICE_NAME, YOUTUBE_API_VERSION, developerKey=developerKey)

    results = my_serviece.commentThreads().list(
        part = "snippet",
        videoId = video_id,
        textFormat="plainText",
    ).execute()

    comments = []

    for item in results['items']:
        comment = item['snippet']['topLevelComment']['snippet']
        author = comment['authorDisplayName']
        text = comment['textDisplay']
        published_at = comment['publishedAt']
        comments.append({
            'author' : author,
            'text' : text,
            'published_at' : published_at
        })
    return comments

comments = youtube_comments("kTmHOUMtBLM")
print(comments)

################API_1000에 있는 YouTubeComments class 가져오기################
#mj = YouTubeComments()  # YouTubeComments 객체를 생성합니다.
#schedule.every().day.at("11:30").do(mj.everyday_time)  # 매일 11시에 mj 객체의 everyday_time 메소드를 실행합니다.

#while True:  # 무한루프
    #schedule.run_pending()  # 예약된 작업을 실행합니다.
    #time.sleep(1)  # 1초 동안 실행을 멈춥니다.





#csv파일로 변환하는 방법_1
import pandas as pd
#csv파일로 변환하는 방법_2
comments_result = youtube_comments("kTmHOUMtBLM") #youtube_comments함수를 호출하여, 댓글 정보를 담은 딕셔너리를 가져오고,데이터프레임으로 변환한다.
df_result = pd.DataFrame(comments_result)
#csv파일로 변환하는 방법_3 : 특정 디렉토리에 csv파일을 저장
df_result.to_csv('C:\\Users\\wkdal\\Desktop\\2023\\04. 석사 학위 논문\\03.데이터\\Youtube-data\\2022블라인드\\2022_블라인드.csv', index=False)
